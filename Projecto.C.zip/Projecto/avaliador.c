#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include "avaliador.h"

#define MAX_PILHA 100

// Estrutura de pilha simples
typedef struct {
    double itens[MAX_PILHA];
    int topo;
} Pilha;

void init(Pilha *p) {
    p->topo = -1;
}

int vazia(Pilha *p) {
    return p->topo == -1;
}

void push(Pilha *p, double valor) {
    p->itens[++p->topo] = valor;
}

double pop(Pilha *p) {
    return !vazia(p) ? p->itens[p->topo--] : 0;
}

double topo(Pilha *p) {
    return !vazia(p) ? p->itens[p->topo] : 0;
}

int operador(char c) {
    return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
}

int precedencia(char op) {
    switch (op) {
        case '^': return 3;
        case '*': case '/': return 2;
        case '+': case '-': return 1;
    }
    return 0;
}

// Aplica a operação entre dois valores
int aplicar(char op, double b, double a, double *res) {
    if (op == '/' && b == 0) return 0;
    switch (op) {
        case '+': *res = a + b; break;
        case '-': *res = a - b; break;
        case '*': *res = a * b; break;
        case '/': *res = a / b; break;
        case '^': *res = pow(a, b); break;
        default: return 0;
    }
    return 1;
}

int avaliar_expressao(const char *expr, double *res, char *erro) {
    Pilha valores, ops;
    init(&valores);
    init(&ops);

    for (int i = 0; expr[i]; i++) {
        char c = expr[i];

        if (isspace(c)) continue;

        if (!isdigit(c) && !operador(c) && c != '(' && c != ')') {
            strcpy(erro, "Erro: Caractere inválido");
            return 0;
        }

        if (isdigit(c)) {
            push(&valores, c - '0');
        } else if (c == '(') {
            push(&ops, c);
        } else if (c == ')') {
            int ok = 0;
            while (!vazia(&ops) && topo(&ops) != '(') {
                char o = (char)pop(&ops);
                double b = pop(&valores);
                double a = pop(&valores);
                double r;
                if (!aplicar(o, b, a, &r)) {
                    strcpy(erro, "Erro: Divisão por zero");
                    return 0;
                }
                push(&valores, r);
            }
            if (!vazia(&ops) && topo(&ops) == '(') {
                pop(&ops);
                ok = 1;
            }
            if (!ok) {
                strcpy(erro, "Erro: Parênteses mal balanceados");
                return 0;
            }
        } else {
            while (!vazia(&ops) && precedencia((char)topo(&ops)) >= precedencia(c)) {
                char o = (char)pop(&ops);
                double b = pop(&valores);
                double a = pop(&valores);
                double r;
                if (!aplicar(o, b, a, &r)) {
                    strcpy(erro, "Erro: Operação inválida");
                    return 0;
                }
                push(&valores, r);
            }
            push(&ops, c);
        }
    }

    while (!vazia(&ops)) {
        char o = (char)pop(&ops);
        double b = pop(&valores);
        double a = pop(&valores);
        double r;
        if (!aplicar(o, b, a, &r)) {
            strcpy(erro, "Erro: Divisão por zero ou algo errado");
            return 0;
        }
        push(&valores, r);
    }

    if (valores.topo != 0) {
        strcpy(erro, "Erro: Expressão malformada");
        return 0;
    }

    *res = pop(&valores);
    return 1;
}