PROJETO: Avaliador de Expressões Matemáticas
Autor: Estudante de Lógica de Programação

DESCRIÇÃO:
Este programa recebe um ficheiro de entrada com expressões matemáticas simples (como "2+3*(1+1)")
e escreve os resultados em um ficheiro de saída. Ele suporta os operadores +, -, *, / e ^ (potência).

COMO COMPILAR:
    gcc main.c avaliador.c -o avaliador

COMO EXECUTAR:
    ./avaliador entrada.txt saida.txt

EXEMPLO DE ENTRADA (entrada.txt):
    2+3*2
    8/(4-4)
    (1+2)*(3+4)

EXEMPLO DE SAÍDA (saida.txt):
    8
    Erro: Divisão por zero
    21