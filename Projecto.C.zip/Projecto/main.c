#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "avaliador.h"

// Programa principal: lê expressões de um arquivo e escreve resultados noutro
int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Modo de uso: %s entrada.txt saida.txt\n", argv[0]);
        return 1;
    }

    FILE *f_entrada = fopen(argv[1], "r");
    FILE *f_saida = fopen(argv[2], "w");

    if (!f_entrada || !f_saida) {
        printf("Erro ao abrir os ficheiros.\n");
        return 1;
    }

    char linha[256];
    while (fgets(linha, sizeof(linha), f_entrada)) {
        double resultado;
        char erro[100] = "";

        linha[strcspn(linha, "\n")] = '\0'; // remove \n no fim

        if (avaliar_expressao(linha, &resultado, erro)) {
            fprintf(f_saida, "%.0f\n", resultado);
        } else {
            fprintf(f_saida, "%s\n", erro);
        }
    }

    fclose(f_entrada);
    fclose(f_saida);
    return 0;
}