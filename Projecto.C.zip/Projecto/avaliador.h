#ifndef AVALIADOR_H
#define AVALIADOR_H

// Avalia a expressão passada como string.
// Retorna 1 se sucesso ou 0 se erro (mensagem preenchida em 'erro')
int avaliar_expressao(const char *expr, double *res, char *erro);

#endif